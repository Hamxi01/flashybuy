 <script>
            var resizefunc = [];
        </script>
        

        <!-- Plugins  -->
        <script src="../admin/assets/js/jquery.min.js"></script>
        <script src="../admin/assets/js/bootstrap.min.js"></script>
        <script src="../admin/assets/js/detect.js"></script>
        <script src="../admin/assets/js/fastclick.js"></script>
        <script src="../admin/assets/js/jquery.slimscroll.js"></script>
        <script src="../admin/assets/js/jquery.blockUI.js"></script>
        <script src="../admin/assets/js/waves.js"></script>
        <script src="../admin/assets/js/wow.min.js"></script>
        <script src="../admin/assets/js/jquery.nicescroll.js"></script>
        <script src="../admin/assets/js/jquery.scrollTo.min.js"></script>
        <script src="../admin/assets/plugins/switchery/switchery.min.js"></script>
       
        <script src="../admin/assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
     
        <!-- <script src="../../admin/assets/plugins/counterup/jquery.counterup.min.js"></script> -->
        <script src="../admin/assets/plugins/jquery-circliful/js/jquery.circliful.min.js"></script>
        <script src="../admin/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="../admin/assets/plugins/skyicons/skycons.min.js" type="text/javascript"></script>

         <script src="../admin/assets/plugins/timepicker/bootstrap-timepicker.min.js"></script>
        <script src="../admin/assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>  

         <script src="../admin/assets/plugins/moment/moment.js"></script>
        <script src="../admin/assets/plugins/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>

        
        <!-- Page js  -->
        <script src="../admin/assets/pages/jquery.dashboard.js"></script>
        <!-- Custom main Js -->
        <script src="../admin/assets/js/jquery.core.js"></script>
        <script src="../admin/assets/js/jquery.app.js"></script>


        
        <!-- external datatable js by rameez -->
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
<script>
            $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
        </script>
        <!-- End external Table js -->
        
    
    </body>
</html>