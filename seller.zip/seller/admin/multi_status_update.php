<?php 
	echo $_POST;
	exit();
?>