<?php
include_once('../../includes/db.php');
$obj = new connection();
if (isset($_POST['btnsub'])) 
{	
	
	$id 	=$_POST['txtid'];
	$title 	= $_POST['title'];
	$url 	= $_POST['url'];
	$image  = $_FILES['img']['name'];
$upload = move_uploaded_file($_FILES['img']['tmp_name'],"crousel/".$image);
if ($upload) 
	{
		echo "<script>alert('ok')</script>";
			$update = 
			mysqli_query($obj->connect(),"update tbl_slider set title='$title' , url = '$url' , image ='$image' where id = '$id' ");
			if ($update>0) 
			{
				echo "update";
			}
			else
			{
				echo "error";
			}
		
}
}


 ?>
